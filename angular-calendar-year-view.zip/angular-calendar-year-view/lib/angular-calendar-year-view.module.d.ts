export declare class AngularCalendarYearViewModule {
}
