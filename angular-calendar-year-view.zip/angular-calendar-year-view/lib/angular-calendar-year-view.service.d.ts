export declare class AngularCalendarYearViewService {
    constructor();
}
